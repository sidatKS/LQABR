"""mcp/mailgun — the central Mailgun tool folder.

Sibling of `mcp/hubspot/`, same rules: it sits at the project ROOT, not
under any agent, and it is loaded **in-process at runtime**. No second
process, no second instance, no service running on its own.

    events.py   fetch_event_status — "give me the status of these track IDs"

Why this exists (Platform Engineering call, 2026-08-04):

    Swaroop, 16:46 — "That is a tool call, right? Why do you need a webhook?"
    Swaroop, 17:02 — "You already have a tool call, MCP."
    Swaroop, 20:27 — "you fetch one pull saying that, you know, these are the
                      IDs, track IDs, give me the status of those track IDs
                      that I got a trigger from. You are going to fetch it,
                      and then if there is anything update, you are going to
                      put it."

So when the agent needs the current state of messages it has already sent,
it makes a **tool call to Mailgun** — it does not stand up a listener and it
does not run a scheduler.

*** What this module must never become ***

    Swaroop, 18:43 — "the reason I'm constantly forcing you guys to not use
                      webhooks is the cost. [A webhook] is a scheduler. It
                      has to run somewhere... you have to keep that agent
                      constantly up and running. Every 30 seconds... that's
                      an expense."

There is therefore **no polling loop and no scheduler in here**. Every
function is called once, on demand, inside a run that a trigger already
started — and the container goes back to zero instances when that run ends.
Adding a background thread, a `while True`, or a Cloud Scheduler entry that
wakes this agent to check Mailgun would defeat the whole design.

Observability: shared by every agent, so it must not import any one agent's
logging. Callers pass the same `ObservabilitySink` protocol `mcp/hubspot`
uses, and get a no-op if they pass nothing.
"""

from __future__ import annotations

from mcp.hubspot import NullObservability, ObservabilitySink

__all__ = ["ObservabilitySink", "NullObservability"]
