"""Email Agent — the ADK wrapper. v2.

    adk web  agents/email/src
    adk run  agents/email/src
    adk api_server agents/email/src     # what Cloud Run serves

One process, one container, one run ID, four log streams. This module is
only the model-facing surface: the deterministic work lives in typed,
mockable modules beside it, and every HubSpot hop goes through the central
MCP at the project root.

    STEP 3    observability.bind_run       run start, correlation token
    STEP 4    mcp/hubspot/auth.py          machine-to-machine bearer
    STEP 5    mcp/hubspot/server.py        get_lead_profile_details
    STEP 6    skills/ + one model call     construct the email
    STEP 7    outreach.py                  send, one email per lead
    STEP 8/9  events.py + service_app.py   engagement events, write-back
    STEP 10   the campaign-complete column hands the lead to text/voice

The gateway (step 2) invokes this agent with a trigger ID and nothing more;
no profile payload passes through it, and agents never call each other.
"""

from __future__ import annotations

import os
import sys
from pathlib import Path
from typing import Any, Dict

from google.adk.agents import Agent

import observability as obs
import outreach
from runstate import RunStateStore

from lqabr_core.crm import CRMError
from lqabr_core.model import build_model

_REPO_ROOT = Path(__file__).resolve().parents[3]
if str(_REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(_REPO_ROOT))

from mcp.hubspot.schema import SchemaValidationError  # noqa: E402
from mcp.hubspot.server import build_session  # noqa: E402

MODEL = os.environ.get("LQABR_EMAIL_MODEL", "gemini-2.0-flash")

obs.configure_logging()
obs.system(event="container_started", component="email-agent", model=MODEL)


# --------------------------------------------------------------------- tools
def run_email_campaign(object_id: str, limit: int = 0, dry_run: bool = False) -> Dict[str, Any]:
    """Run one outreach campaign for a HubSpot campaign trigger — the agent's
    main entry point.

    Args:
        object_id: the ID the HubSpot campaign fired at the gateway. The
            lead profiles are chunked under it and stay in HubSpot; this is
            the only thing the trigger carries.
        limit: max leads to work this run (0 = the configured batch size).
        dry_run: construct every email and report it, but send nothing.
            Use this when the operator asks to preview a campaign.

    Returns per-lead results plus an `unresolved` list — any lead that could
    not be worked is there with an explicit reason, never dropped. Delivery,
    opens and clicks are recorded later by the Mailgun webhook, never here.
    """
    try:
        return outreach.run_campaign(object_id, limit=limit, dry_run=dry_run)
    except CRMError as exc:
        return {"error": f"crm-error: {exc}", "object_id": object_id}


def preview_email(contact_email: str, cta_url: str = "") -> Dict[str, Any]:
    """Show which skill a lead would get and what the email would say —
    without sending anything and without touching run state. Read-only."""
    ctx = obs.bind_run(object_id=f"preview-{contact_email}")
    session = build_session(obs=obs.MCPObservability(ctx))
    try:
        lead = session.crm.find_by_email(contact_email)
        if lead is None or not lead.hubspot_contact_id:
            return {"error": f"no HubSpot contact for {contact_email}"}
        profile = session.crm.get_lead_profile(lead.hubspot_contact_id)
    except SchemaValidationError as exc:
        return {"error": str(exc)}
    except CRMError as exc:
        return {"error": f"crm-error: {exc}"}

    # Construction is instruction-based, so a preview must draft with the
    # model too — there is no template to render without one. A preview that
    # could not reach the model reports that rather than showing copy the
    # campaign would never actually send.
    try:
        subject, html_body, skill = outreach.construct_email(
            ctx, profile, model_fn=outreach.build_model_fn(ctx), cta_url=cta_url)
    except outreach.skills.SkillError as exc:
        return {"error": f"construction: {exc}", "contact_id": profile.contact_id,
                "skill": outreach.skills.select_skill(profile.industry)[0].name}
    return {"contact_id": profile.contact_id, "to": profile.email_id, "skill": skill,
            "subject": subject, "html_body": html_body,
            "missing_pointers": profile.missing_pointers}


def send_outreach_email(contact_email: str, object_id: str = "",
                        cta_url: str = "") -> Dict[str, Any]:
    """Send one outreach email to one named lead, through the full step 4-7
    path (bearer, MCP profile read, skill selection, Mailgun send, run state).

    Use this when the operator names a specific recipient. For a campaign,
    use run_email_campaign instead — that is the designed entry point.

    Args:
        contact_email: the lead's email; must already exist in HubSpot.
        object_id: the campaign trigger to correlate this send under. A
            manual id is generated when the operator has none.
        cta_url: link for the call-to-action; clicks on it are tracked.
    """
    ctx, session = outreach.start_run(object_id or f"manual-{contact_email}")
    try:
        lead = session.crm.find_by_email(contact_email)
        if lead is None or not lead.hubspot_contact_id:
            obs.process(ctx, step=5, event="lead_unresolved", contact_email=contact_email,
                        reason="bad-data: no HubSpot contact")
            return {"error": f"no HubSpot contact for {contact_email} — ingest the lead first"}
        profile = session.crm.get_lead_profile(lead.hubspot_contact_id)
    except SchemaValidationError as exc:
        return {"error": str(exc)}
    except CRMError as exc:
        return {"error": f"crm-error: {exc}"}

    try:
        subject, html_body, skill = outreach.construct_email(
            ctx, profile, model_fn=outreach.build_model_fn(ctx), cta_url=cta_url)
    except outreach.skills.SkillError as exc:
        return {"error": f"construction: {exc}", "contact_id": profile.contact_id}
    result = outreach.send_one(ctx, session, profile, subject, html_body, skill)
    result["object_id"] = ctx.object_id
    result["run_id"] = ctx.run_id
    return result


def get_lead_status(contact_email: str) -> Dict[str, Any]:
    """One lead's current email status and probability, read-only.

    Works for leads already contacted, which the outreach queue no longer
    shows. Never claim an email was opened or clicked unless this says so."""
    ctx = obs.bind_run(object_id=f"status-{contact_email}")
    session = build_session(obs=obs.MCPObservability(ctx))
    try:
        lead = session.crm.find_by_email(contact_email)
    except CRMError as exc:
        return {"error": f"crm-error: {exc}"}
    if lead is None or not lead.hubspot_contact_id:
        return {"error": f"no HubSpot contact for {contact_email}"}
    return {
        "contact_id": lead.hubspot_contact_id,
        "email": lead.email,
        "email_status": (lead.extra or {}).get("email_status"),
        "probability": lead.probability,
        "company": lead.company,
        "job_title": lead.job_title,
    }


def list_email_queue(object_id: str = "", limit: int = 25) -> Dict[str, Any]:
    """The leads chunked under a campaign trigger and awaiting outreach.

    With no object_id, falls back to the not-yet-emailed queue so an
    operator can still see what is outstanding."""
    ctx = obs.bind_run(object_id=object_id or "queue-inspection")
    session = build_session(obs=obs.MCPObservability(ctx))
    try:
        leads = session.crm.leads_for_trigger(object_id or ctx.object_id, limit=limit)
    except CRMError as exc:
        return {"error": f"crm-error: {exc}"}
    return {"count": len(leads), "object_id": object_id or None,
            "leads": [lead.to_dict() for lead in leads]}


def get_run_state(object_id: str, run_id: str) -> Dict[str, Any]:
    """What a past run sent, and what has come back for it so far. Use this
    to answer 'did this run get stuck' without inventing engagement."""
    return RunStateStore().summary(object_id, run_id)


root_agent = Agent(
    name="email_agent",
    model=build_model(MODEL),
    description=("LQABR Email Agent (v2): runs a HubSpot campaign trigger end to "
                 "end — reads each lead's 9-parameter profile through the central "
                 "HubSpot MCP, selects a templatized email skill from the lead's "
                 "industry, personalises it with one model call per lead, and "
                 "sends one Mailgun email per lead tagged with the run's "
                 "correlation token. Delivery, opens and clicks return "
                 "asynchronously to the webhook and are written back to HubSpot."),
    instruction=(
        "You are the LQABR email outreach agent.\n\n"
        "The designed entry point is a campaign trigger: when you are given a "
        "trigger ID, call run_email_campaign with it. That single call binds "
        "the run's correlation token, acquires the HubSpot bearer, reads each "
        "lead's profile through the central MCP, chooses the email skill, and "
        "sends one email per lead. Report its `results` and `unresolved` "
        "lists exactly as returned — an unresolved lead is a real outcome, "
        "not a failure to hide.\n\n"
        "Use dry_run=True when the operator wants to preview a campaign "
        "before it goes out, and preview_email when they ask what a single "
        "named lead would receive.\n\n"
        "When the operator names one specific recipient to contact now, call "
        "send_outreach_email for that address. Use get_lead_status to check "
        "one lead's current status without sending anything, and "
        "list_email_queue to see what is outstanding.\n\n"
        "Email content is templatized and skill-based. The skill is selected "
        "from the lead's real industry and fields — you do not write the "
        "email from scratch and you never write one email for a batch. Only "
        "state facts present in the lead's profile; if a field is missing, "
        "the skill writes around it rather than inventing a value.\n\n"
        "Never invent an email address: only contact leads returned from "
        "HubSpot. Report Mailgun and CRM errors verbatim — a failed send is "
        "never ignored, and a rejected send resolves to a terminal status "
        "that ends that lead's run. Engagement is recorded only by the "
        "Mailgun webhook: never claim an email was delivered, opened or "
        "clicked unless get_lead_status or get_run_state actually shows it."
    ),
    tools=[run_email_campaign, preview_email, send_outreach_email,
           get_lead_status, list_email_queue, get_run_state],
)
